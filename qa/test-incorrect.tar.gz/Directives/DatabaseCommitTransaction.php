<?php /*dlv-code-engine***/

$db = $state->memory()->get('db-conn');
$db->exec('COMMIT');