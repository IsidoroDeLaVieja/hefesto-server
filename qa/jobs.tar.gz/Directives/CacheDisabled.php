<?php /*dlv-code-engine***/

$state->message()->setHeader('Cache-Control','no-cache');
$state->message()->deleteHeader('Expires');