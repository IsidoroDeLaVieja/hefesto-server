<?php /*dlv-code-engine***/

$state->message()->setHeader('Content-Type','application/json');
$state->message()->setBodyAsArray(['message' => 'pong']);