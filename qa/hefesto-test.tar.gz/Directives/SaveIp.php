<?php /*dlv-code-engine***/

$state->addDebug([
    'ip' => $_SERVER['REMOTE_ADDR']
]);