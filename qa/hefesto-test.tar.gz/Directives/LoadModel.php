<?php /*dlv-code-engine***/

$state->memory()->set($config['target'],$config['source']);