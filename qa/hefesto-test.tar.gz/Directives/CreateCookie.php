<?php /*dlv-code-engine***/

setcookie('myname','myvalue');